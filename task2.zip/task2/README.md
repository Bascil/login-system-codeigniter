LoginWithCI

Coded with  CodeIgniter and  Bootstrap

Extract zip and use SQL file to create DB

Run the project in localhost

Login >
Username: admin
Password: 123
