
<?php
  error_reporting(0);
 $a = $_REQUEST['num1'];
 $b = $_REQUEST['num2'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home | Zydii</title>
    <link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/css/custom.css" rel="stylesheet">
    <script language="javascript">
         function validate_form(){
            var num1 = document.entryform.num1;
            var num2 = document.entryform.num2;

            if (num1.value==""|| num1.value==null){
                alert("Please specify value on first box");
                num1.focus();

                return false;
            }

            else if (num2.value=="" || num2.value==null){
                alert("Please specify value on second box");
                num2.focus();

                return false;
                }
            }
      </script>
</head>
<body>
    <nav class="navbar navbar-inverse navbar-static-top">

        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#" style="font-size: 40px; font-weight: bold; color: whitesmoke;">Zydii</a>
        </div>


    <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
        
                <li class="active"><a href="#">HOME<span class="sr-only">(current)</span></a></li>
            
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                <?php echo $_SESSION['username'];?><span class="caret"></span></a>
                <ul class="dropdown-menu">
                <li role="separator" class="divider"></li>
                    <li><a href='#'>Profile</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href='<?php echo base_url(); ?>index.php/Login/logoutUser'>Logout</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
<div class='container' style='margin-top: 40px;'>

    <!-- temporary message for a successful landing to the home page -->
    <?php if ($this->session->flashdata('success')) {?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php echo $this->session->flashdata('success'); ?>
        </div>
    <?php  } ?>
    <?php echo validation_errors('<div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>','</div>');
    ?>

    <?php 

    if (isset($_REQUEST['clear'])){
            $a="";
            $b=""; 
     }
   
          
          ?>

    <div class="jumbotron">
        <h2>Hello <?php echo $_SESSION['username'];?></h2>
       <form method="post" onSubmit="return validate_form(this)" name="entryform">
                <fieldset>
                   
                        <input type="text" name="num1" value="<?php echo $a; ?>" autofocus>

                             <select name="opt_math">
                             <option value="+">Add
                             <option value="-">Subtract
                             <option value="*">Multiply
                             <option value="/">Divide
                             </select>

                        <input type="text" name="num2" value="<?php echo $b; ?>"><br><br>
                        <input type="submit" name="submit" value="Compute">
                        <input type="submit" name="clear" value="Clear">
                         <br><br>
 
                         <span id="result">
                         Result is
                         <strong>
                         <?php
                        if ($_REQUEST['opt_math']=="+"){
                         echo $a+$b;
                         }
                         else if ($_REQUEST['opt_math']=="-"){
                         echo $a-$b;
                         }
                         else if ($_REQUEST['opt_math']=="/"){
                         echo $a/$b;
                         }
                         else if ($_REQUEST['opt_math']=="*"){
                         echo $a*$b;
                         }
                         
                ?>
                </strong>
                </span><br><br><br>
             </fieldset>
             </form>
        <p><a class="btn btn-primary" href="<?php echo site_url('Login/logoutUser') ?>" role="button">Log out</a></p>
    </div>

</div>


    <script src="<?php echo base_url() ?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>
  </body>
</html>
